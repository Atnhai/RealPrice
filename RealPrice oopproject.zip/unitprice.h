#ifndef UNITPRICE_H
#define UNITPRICE_H

#include <QDialog>

namespace Ui {
class UnitPrice;
}

class UnitPrice : public QDialog
{
    Q_OBJECT

public:
    explicit UnitPrice(QWidget *parent = nullptr);
    ~UnitPrice();

private slots:
    void on_pushButton_clicked();

private:
    Ui::UnitPrice *ui;
};

#endif // UNITPRICE_H
