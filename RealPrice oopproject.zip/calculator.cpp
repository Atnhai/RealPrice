#include "calculator.h"
#include "ui_calculator.h"
#include "discountcal.h"
//#include <qmessagebox.h>

//#include <QtDebug>
double firstnum; //global variabal
bool usertypesecondnum = false;

Calculator::Calculator(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Calculator)
{
    ui->setupUi(this);

    //for numbers 0-9
    connect(ui->pushButton_0,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_1,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_2,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_3,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_4,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_5,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_6,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_7,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_8,SIGNAL(released()),this,SLOT(digit_pressed()));
    connect(ui->pushButton_9,SIGNAL(released()),this,SLOT(digit_pressed()));

    //for operator %,+/-
    connect(ui->pushButton_plusminus,SIGNAL(released()),this,SLOT(unary_operation_pressed()));
    connect(ui->pushButton_percent,SIGNAL(released()),this,SLOT(unary_operation_pressed()));
    //for operator +,-,*,/
    connect(ui->pushButton_plus,SIGNAL(released()),this,SLOT(binary_operation_pressed()));
    connect(ui->pushButton_minus,SIGNAL(released()),this,SLOT(binary_operation_pressed()));
    connect(ui->pushButton_multiply,SIGNAL(released()),this,SLOT(binary_operation_pressed()));
    connect(ui->pushButton_divide,SIGNAL(released()),this,SLOT(binary_operation_pressed()));

    ui->pushButton_plus->setCheckable(true);
    ui->pushButton_minus->setCheckable(true);
    ui->pushButton_multiply->setCheckable(true);
    ui->pushButton_divide->setCheckable(true);
}

Calculator::~Calculator()
{
    delete ui;
}

void Calculator::digit_pressed() {
    //qDebug() << "test";
    QPushButton *button = (QPushButton*)sender();
    double labelNumber;
    QString newlabel;

    if((ui->pushButton_plus->isChecked()||ui->pushButton_minus->isChecked()||ui->pushButton_multiply->isChecked()
            ||ui->pushButton_divide->isChecked()) && (!usertypesecondnum))
    {
        labelNumber = button->text().toDouble();
        usertypesecondnum = true;
        newlabel = QString::number(labelNumber,'g',15);
    }
    else
    {
        if(ui->label->text().contains('.') && button->text() == "0")
        {
            newlabel = ui->label->text() + button-> text();
        }
        else
        {
            labelNumber = (ui->label->text()+button->text()).toDouble();
            newlabel = QString::number(labelNumber,'g',15);
        }
        labelNumber = (ui->label->text() + button->text()).toDouble();
    }

    //labelNumber = (ui->label->text()+button->text()).toDouble();
    //newlabel = QString::number(labelNumber,'g',15);
    ui->label->setText(newlabel);

}

void Calculator::on_pushButton_dot_released()
{
    ui->label->setText(ui->label->text() + ".");
}

void Calculator::unary_operation_pressed()
{
    QPushButton * button = (QPushButton*) sender();
    double labelNumber;
    QString newlabel;

    if(button->text() == "+/-")
    {
        labelNumber = ui->label->text().toDouble();
        labelNumber = labelNumber * -1;
        newlabel = QString::number(labelNumber,'g',15);
        ui->label->setText(newlabel);
    }

    if(button->text() == "%")
    {
        labelNumber = ui->label->text().toDouble();
        labelNumber = labelNumber * 0.01;
        newlabel = QString::number(labelNumber,'g',15);
        ui->label->setText(newlabel);
    }

}

void Calculator::on_pushButton_clear_released()
{
    ui->pushButton_plus->setChecked(false);
    ui->pushButton_minus->setChecked(false);
    ui->pushButton_multiply->setChecked(false);
    ui->pushButton_divide->setChecked(false);

    usertypesecondnum = false;
    ui->label->setText("0");


}

void Calculator::on_pushButton_equal_released()
{
    double labelNumber, secondnum;
    QString newlabel;

    secondnum = ui->label->text().toDouble();

    if(ui->pushButton_plus->isChecked())
    {
       labelNumber = firstnum + secondnum;
       newlabel = QString::number(labelNumber,'g',15);
       ui->label->setText(newlabel);
       ui->pushButton_plus->setChecked(false);
    }
    else if(ui->pushButton_minus->isChecked())
    {
        labelNumber = firstnum - secondnum;
        newlabel = QString::number(labelNumber,'g',15);
        ui->label->setText(newlabel);
        ui->pushButton_minus->setChecked(false);

    }
    else if(ui->pushButton_multiply->isChecked())
    {
        labelNumber = firstnum * secondnum;
        newlabel = QString::number(labelNumber,'g',15);
        ui->label->setText(newlabel);
        ui->pushButton_multiply->setChecked(false);
    }
    else if(ui->pushButton_divide->isChecked())
    {
        labelNumber = firstnum / secondnum;
        newlabel = QString::number(labelNumber,'g',15);
        ui->label->setText(newlabel);
        ui->pushButton_divide->setChecked(false);
    }

    usertypesecondnum = false;
}

void Calculator::binary_operation_pressed()
{
    QPushButton * button = (QPushButton*) sender();
    firstnum = ui->label->text().toDouble();

    button->setChecked(true);
}

void Calculator::on_actionDiscount_Calculator_triggered()
{
    discountcal = new DiscountCal(this);
    discountcal->show();
}

void Calculator::on_actionLoan_Calculator_triggered()
{
    loancal = new LoanCal(this);
    loancal->show();
}

void Calculator::on_actionSale_tax_Calculator_triggered()
{
    salestax = new SalestaxCal(this);
    salestax->show();
}

void Calculator::on_actionUnit_price_Calculator_triggered()
{
    unitprice = new UnitPrice(this);
    unitprice->show();
}

void Calculator::on_actionCurrency_Converter_triggered()
{
    currency = new CurrencyCon(this);
    currency->show();
}

void Calculator::on_actionAbout_triggered()
{
    QTextEdit *message = new QTextEdit();
    message->setWindowFlag(Qt::Window);
    message->setReadOnly(true);
    message->append("Real Price is a shopping calculator with 6 difference calculators in the application.");
    message->show();

}
