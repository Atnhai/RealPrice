#include "loancal.h"
#include "ui_loancal.h"

LoanCal::LoanCal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoanCal)
{
    ui->setupUi(this);
    connect(ui->calculate,SIGNAL(released()),this,SLOT(on_pushButton_clicked()));
}

LoanCal::~LoanCal()
{
    delete ui;
}

void LoanCal::on_pushButton_clicked()
{
    double pay,rate,period,tinterest,tpay,tmonth;
    QString newlabel;
    QString newlable2;

    pay = ui->loanp->text().toDouble();
    period = ui->period->text().toDouble();
    rate = ui->rate->text().toDouble();
    rate = rate * 0.01;

    tinterest = pay * rate;
    tpay = pay * (1.00 + rate);
    tmonth = tpay / period;

    newlabel = QString::number(tinterest,'g',15);
    ui->tinterest->setText(newlabel);
    newlabel = QString::number(tpay,'g',15);
    ui->tpay->setText(newlabel);
    newlabel = QString::number(tmonth,'g',15);
    ui->tmonth->setText(newlabel);


}
