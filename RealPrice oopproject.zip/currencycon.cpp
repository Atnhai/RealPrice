#include "currencycon.h"
#include "ui_currencycon.h"

CurrencyCon::CurrencyCon(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CurrencyCon)
{
    QString usd;
    ui->setupUi(this);
    //ui->comboBox->addItem("USD").toDouble();

}

CurrencyCon::~CurrencyCon()
{
    delete ui;
}

void CurrencyCon::on_pushButton_clicked()
{
    double usd,usdb;
    QString newlabel;

    usd = ui->usd->text().toDouble();
    usdb = usd * 32.42;

    newlabel = QString::number(usdb,'g',15);
    ui->usdb->setText(newlabel);
}

void CurrencyCon::on_pushButton_2_clicked()
{
    double cny,cnyb;
    QString newlabel;

    cny = ui->cny->text().toDouble();
    cnyb = cny * 4.59 ;

    newlabel = QString::number(cnyb,'g',15);
    ui->cnyb->setText(newlabel);
}

void CurrencyCon::on_pushButton_3_clicked()
{
    double jpy,jpyb;
    QString newlabel;

    jpy = ui->jpy->text().toDouble();
    jpyb = jpy * 0.30 ;

    newlabel = QString::number(jpyb,'g',15);
    ui->jpyb->setText(newlabel);
}

void CurrencyCon::on_pushButton_4_clicked()
{
    double krw,krwb;
    QString newlabel;

    krw = ui->krw->text().toDouble();
    krwb = krw * 0.026 ;

    newlabel = QString::number(krwb,'g',15);
    ui->krwb->setText(newlabel);

}
