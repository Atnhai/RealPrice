#include "discountcal.h"
#include "ui_discountcal.h"

DiscountCal::DiscountCal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DiscountCal)
{
    ui->setupUi(this);
    //connect(ui->pushButton,SIGNAL(released()),this,SLOT(on_pushButton_clicked()));
}

DiscountCal::~DiscountCal()
{
    delete ui;
}

void DiscountCal::on_pushButton_clicked()
{
    double price,percent,saved,final;
    QString newlabel;
    QString newlable2;

    price = ui->oriprice->text().toDouble();
    percent = ui->dispercent->text().toDouble();
    percent = percent * 0.01;

    saved = price * percent;
    final = price * (1 - percent);

    newlabel = QString::number(saved,'g',15);
    ui->saved->setText(newlabel);
    newlabel = QString::number(final,'g',15);
    ui->finalprice->setText(newlabel);

}
