#include "unitprice.h"
#include "ui_unitprice.h"

UnitPrice::UnitPrice(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UnitPrice)
{
    ui->setupUi(this);
}

UnitPrice::~UnitPrice()
{
    delete ui;
}

void UnitPrice::on_pushButton_clicked()
{
    double price,quantity,unitprice;
    QString newlabel;

    price = ui->price->text().toDouble();
    quantity = ui->quantity->text().toDouble();

    unitprice = price / quantity;

    newlabel = QString::number(unitprice,'g',15);
    ui->unitprice->setText(newlabel);
}
