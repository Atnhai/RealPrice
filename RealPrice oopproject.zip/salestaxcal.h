#ifndef SALESTAXCAL_H
#define SALESTAXCAL_H

#include <QDialog>

namespace Ui {
class SalestaxCal;
}

class SalestaxCal : public QDialog
{
    Q_OBJECT

public:
    explicit SalestaxCal(QWidget *parent = nullptr);
    ~SalestaxCal();

private slots:
    void on_calculate_clicked();

private:
    Ui::SalestaxCal *ui;
};

#endif // SALESTAXCAL_H
