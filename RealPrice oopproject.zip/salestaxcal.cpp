#include "salestaxcal.h"
#include "ui_salestaxcal.h"

SalestaxCal::SalestaxCal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SalestaxCal)
{
    ui->setupUi(this);
}

SalestaxCal::~SalestaxCal()
{
    delete ui;
}

void SalestaxCal::on_calculate_clicked()
{
    double taxrate,oriprice,tax,total;
    QString newlabel;

    oriprice = ui->oriprice->text().toDouble();
    taxrate = ui->taxrate->text().toDouble();
    taxrate = taxrate * 0.01;

    tax = oriprice* taxrate;
    total = oriprice * (1 + taxrate);

    newlabel = QString::number(tax,'g',15);
    ui->tax->setText(newlabel);
    newlabel = QString::number(total,'g',15);
    ui->total->setText(newlabel);
}
