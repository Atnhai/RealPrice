#ifndef LOANCAL_H
#define LOANCAL_H

#include <QDialog>

namespace Ui {
class LoanCal;
}

class LoanCal : public QDialog
{
    Q_OBJECT

public:
    explicit LoanCal(QWidget *parent = nullptr);
    ~LoanCal();

private slots:
    void on_pushButton_clicked();

private:
    Ui::LoanCal *ui;
};

#endif // LOANCAL_H
