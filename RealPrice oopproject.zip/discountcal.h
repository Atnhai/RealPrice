#ifndef DISCOUNTCAL_H
#define DISCOUNTCAL_H

#include <QDialog>

namespace Ui {
class DiscountCal;
}

class DiscountCal : public QDialog
{
    Q_OBJECT

public:
    explicit DiscountCal(QWidget *parent = nullptr);
    ~DiscountCal();

private slots:
    void on_pushButton_clicked();

private:
    Ui::DiscountCal *ui;
};

#endif // DISCOUNTCAL_H
