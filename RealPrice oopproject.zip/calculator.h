#ifndef CALCULATOR_H
#define CALCULATOR_H

#include <QMainWindow>
#include <QTextEdit>
#include "discountcal.h"
#include "loancal.h"
#include "salestaxcal.h"
#include "unitprice.h"
#include "currencycon.h"

QT_BEGIN_NAMESPACE
namespace Ui { class Calculator; }
QT_END_NAMESPACE

class Calculator : public QMainWindow
{
    Q_OBJECT

public:
    Calculator(QWidget *parent = nullptr);
    ~Calculator();

private:
    Ui::Calculator *ui;
    DiscountCal *discountcal;
    LoanCal *loancal;
    SalestaxCal *salestax;
    UnitPrice *unitprice;
    CurrencyCon *currency;
private slots:
    void digit_pressed();
    void on_pushButton_dot_released();
    void unary_operation_pressed();
    void on_pushButton_clear_released();
    void on_pushButton_equal_released();
    void binary_operation_pressed();
    void on_actionDiscount_Calculator_triggered();
    void on_actionLoan_Calculator_triggered();
    void on_actionSale_tax_Calculator_triggered();
    void on_actionUnit_price_Calculator_triggered();
    void on_actionCurrency_Converter_triggered();
    void on_actionAbout_triggered();
};
#endif // CALCULATOR_H
